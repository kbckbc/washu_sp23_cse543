+ How to run

1. Place ‘mvp.mod’ ‘mmvp.mod’ ‘mvp.dat’ files in the same directory which can run ‘ampl’ CLI(Command Line Interface).
   'mvp.mod' is AMPL execution file for ‘Minimum Variance Portfolio’.
   'mmvp.mod' is AMPL execution file for ‘Modified Minimum Variance Portfolio’.
   'mvp.dat' is AMPL data file.

2. If you want to change the parameter, you can change parameter directly in the mod files.
   The default parameter value is for group 1(grp_type = 1)
   Open ‘mvp.mod’ or ‘mmvp.mod’ and edit the parameter ‘grp_type’ from 1 to 4. 
   'grp_type' have 4 cases and they are like below.
   
   * grp_type 1, 2, 3, 4
      Group1: Apple, United Health Care, Coca-Cola
      Group2: MS, J&J, Walmart
      Group3: Netflix, Merck, Pepsi
      Group4: Google, abbive, P&G

3. Run AMPL CLI.

4. Execute the ampl mod files in the AMPL CLI like below.
   model mvp.mod
   or
   model mmvp.mod
